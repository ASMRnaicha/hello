import os
import re
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'Using device: {device}')

# 数据预处理函数
def preprocess(folder_path):
    labels = []
    data = []
    for filename in os.listdir(folder_path):
        if filename.endswith(".bin"):
            match = re.search(r'label_(\d+)_', filename)
            if match:
                label = int(match.group(1))
            else:
                continue

            with open(os.path.join(folder_path, filename), 'rb') as file:
                data_row_bin = file.read()
                data_row_float16 = np.frombuffer(data_row_bin, dtype=np.float16)
                data_row_float32 = data_row_float16.astype(np.float32)  # 转换为 float32
                paired_data = data_row_float32.reshape(-1, 2)  # 两两配对
                labels.append(label)
                data.append(paired_data)
                
    return np.array(data), np.array(labels)

path1 = 'train_set_remake'
data1, labels1 = preprocess(path1)

print(f"Data shape: {data1.shape}")
print(f"Labels shape: {labels1.shape}")

# 数据分割
from sklearn.utils import shuffle
X, y = shuffle(data1, labels1, random_state=42)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 数据标准化
scaler = StandardScaler()
X_train_reshaped = X_train.reshape(X_train.shape[0], -1)
X_test_reshaped = X_test.reshape(X_test.shape[0], -1)

X_train_scaled = scaler.fit_transform(X_train_reshaped).reshape(X_train.shape)
X_test_scaled = scaler.transform(X_test_reshaped).reshape(X_test.shape)

# 创建自定义数据集
class ComplexDataset(Dataset):
    def __init__(self, data, labels, augment=False):
        self.data = data
        self.labels = labels
        self.augment = augment

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        sample_data = self.data[idx]
        sample_label = self.labels[idx]

        return torch.tensor(sample_data, dtype=torch.float32), torch.tensor(sample_label, dtype=torch.long)

train_dataset = ComplexDataset(X_train_scaled, y_train, augment=True)
val_dataset = ComplexDataset(X_test_scaled, y_test, augment=False)

train_loader = DataLoader(train_dataset, batch_size=128, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=128, shuffle=False)

# 简化后的FT-Transformer模型
class SimplifiedFTTransformer(nn.Module):
    def __init__(self, input_dim, num_classes, dim_model=64, num_heads=2, num_layers=1, dropout=0.1):
        super(SimplifiedFTTransformer, self).__init__()
        self.embedding = nn.Linear(input_dim, dim_model)
        encoder_layer = nn.TransformerEncoderLayer(d_model=dim_model, nhead=num_heads, dropout=dropout)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.classifier = nn.Linear(dim_model, num_classes)
    
    def forward(self, x):
        batch_size, seq_len, feature_dim = x.shape
        x = x.view(batch_size, -1)  # 展平特征维度
        x = self.embedding(x)
        x = self.transformer_encoder(x.unsqueeze(1))
        x = x.mean(dim=1)
        x = self.classifier(x)
        return x

# 初始化和训练FT-Transformer模型
input_dim = X_train_scaled.shape[1] * X_train_scaled.shape[2]  # 展平后的输入维度
num_classes = len(np.unique(y))
model = SimplifiedFTTransformer(input_dim=input_dim, num_classes=num_classes).to(device)

criterion = nn.CrossEntropyLoss()
learning_rate = 2e-5
weight_decay = 1e-5
optimizer = optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=weight_decay)
scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.1, patience=10, verbose=True)

num_epochs = 1000

# 记录最佳模型信息的函数
def save_best_model(model, accuracy, batch_size, learning_rate, weight_decay, epoch, path='best_model_co.pth'):
    torch.save(model.state_dict(), path)
    with open('best_model_info_co.txt', 'w') as f:
        f.write(f'Accuracy: {accuracy}\n')
        f.write(f'Batch size: {batch_size}\n')
        f.write(f'Learning rate: {learning_rate}\n')
        f.write(f'Weight decay: {weight_decay}\n')
        f.write(f'Epoch: {epoch}\n')

# 读取当前最佳模型的准确率
def load_best_accuracy():
    if os.path.exists('best_model_info_co.txt'):
        with open('best_model_info_co.txt', 'r') as f:
            lines = f.readlines()
            for line in lines:
                if line.startswith('Accuracy'):
                    return float(line.split(': ')[1])
    return 0.0

best_accuracy = load_best_accuracy()

for epoch in range(num_epochs):
    model.train()
    total_loss = 0
    for inputs, targets in train_loader:
        inputs, targets = inputs.to(device), targets.to(device)
        optimizer.zero_grad()
        
        outputs = model(inputs)
        loss = criterion(outputs, targets)
        
        loss.backward()
        optimizer.step()
        
        total_loss += loss.item()

    avg_loss = total_loss / len(train_loader)
    print(f'Epoch {epoch+1}/{num_epochs}, Loss: {avg_loss:.4f}')

    # 评估模型在验证集上的表现
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        total_loss = 0
        for inputs, targets in val_loader:
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            total_loss += loss.item()
            _, y_pred_ft = torch.max(outputs, 1)
            correct += (y_pred_ft == targets).sum().item()
        avg_val_loss = total_loss / len(val_loader)
    
    accuracy = correct / len(val_dataset)
    print(f'Validation Accuracy after epoch {epoch+1}: {accuracy:.4f}, Validation Loss: {avg_val_loss:.4f}')

    # 调整学习率
    scheduler.step(avg_val_loss)
    
    # 保存最佳模型
    if accuracy > best_accuracy:
        best_accuracy = accuracy
        save_best_model(model, accuracy, train_loader.batch_size, learning_rate, weight_decay, epoch+1)

    # 提前停止
    if epoch > 20 and accuracy < 0.2:
        print("Early stopping due to low accuracy")
        break

# 打印预测结果的示例
print(f'Sample predictions: {y_pred_ft[:10]}')
