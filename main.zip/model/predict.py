import os
import re
import numpy as np
from sklearn.preprocessing import StandardScaler
import torch
import torch.nn as nn

# 数据预处理函数
def preprocess(folder_path):
    labels = []
    data = []
    for filename in os.listdir(folder_path):
        if filename.endswith(".bin"):
            match = re.search(r'label_(\d+)_', filename)
            if match:
                label = int(match.group(1))
            else:
                continue
            with open(os.path.join(folder_path, filename), 'rb') as file:
                data_row_bin = file.read()
                data_row_float16 = np.frombuffer(data_row_bin, dtype=np.float16)
                data_row_float32 = data_row_float16.astype(np.float32)  # 转换为 float32
                paired_data = data_row_float32.reshape(-1, 2)  # 两两配对
                labels.append(label)
                data.append(paired_data)
    return np.array(data), np.array(labels)

# 加载模型
model_path = 'best_model_co.pth'
input_dim = data1.shape[1] * data1.shape[2]  # 展平后的输入维度
num_classes = len(np.unique(y))
model = SimplifiedFTTransformer(input_dim=input_dim, num_classes=num_classes).to(device)
model.load_state_dict(torch.load(model_path, map_location=device))
model.eval()

# 推理函数
def predict(model, data):
    data_tensor = torch.tensor(data, dtype=torch.float32).to(device).view(data.shape[0], data.shape[1], -1)
    with torch.no_grad():
        outputs = model(data_tensor)
        _, y_pred = torch.max(outputs, 1)
    return y_pred.cpu().numpy()

# 推理并输出结果
def inference_and_output(folder_path, output_filename):
    data, _ = preprocess(folder_path)
    predictions = predict(model, data)
    with open(output_filename, "w", newline='') as file:
        writer = csv.writer(file)
        for prediction in predictions:
            writer.writerow([prediction])

# 使用示例
test_folder_path = 'test_set'
output_filename = 'result.csv'
inference_and_output(test_folder_path, output_filename)
