#include <iostream>
#include <vector>
#include <algorithm>
#include <unordered_map>

struct Task {
    int msgType;
    int usrInst;
    int exeTime;
    int deadLine;

    Task(int m, int u, int e, int d) : msgType(m), usrInst(u), exeTime(e), deadLine(d) {}
};

struct Core {
    int id;
    int currentTime;
    std::vector<Task> tasks;

    Core(int i) : id(i), currentTime(0) {}
};

bool compareTasks(const Task& a, const Task& b) {
    return a.deadLine < b.deadLine;
}

int main() {
    int N, M, C;
    std::cin >> N >> M >> C;

    std::vector<Task> tasks;
    for (int i = 0; i < N; ++i) {
        int msgType, usrInst, exeTime, deadLine;
        std::cin >> msgType >> usrInst >> exeTime >> deadLine;
        tasks.emplace_back(msgType, usrInst, exeTime, deadLine);
    }

    // Sort tasks by deadline
    std::sort(tasks.begin(), tasks.end(), compareTasks);

    // Initialize cores
    std::vector<Core> cores;
    for (int i = 0; i < M; ++i) {
        cores.emplace_back(i);
    }

    // Map to track the last core used by each user instance
    std::unordered_map<int, int> lastCoreForUsrInst;

    // Distribute tasks to cores
    for (const auto& task : tasks) {
        int minCore = -1;
        int minTime = INT_MAX;

        // Find the best core to place the task
        for (int i = 0; i < M; ++i) {
            if (lastCoreForUsrInst[task.usrInst] == i || cores[i].currentTime < minTime) {
                minCore = i;
                minTime = cores[i].currentTime;
            }
        }

        // Assign task to the selected core
        cores[minCore].tasks.push_back(task);
        cores[minCore].currentTime += task.exeTime;
        lastCoreForUsrInst[task.usrInst] = minCore;
    }

    // Output the result
    for (const auto& core : cores) {
        std::cout << core.tasks.size();
        for (const auto& task : core.tasks) {
            std::cout << " " << task.msgType << " " << task.usrInst;
        }
        std::cout << std::endl;
    }
    system("pause");
    return 0;
}
